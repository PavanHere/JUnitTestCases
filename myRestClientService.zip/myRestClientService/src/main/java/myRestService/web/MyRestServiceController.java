package myRestService.web;

import javax.inject.Inject;

import myRestService.domain.MyMainResponse;
import myRestService.domain.MyRestServiceRequest;
import myRestService.service.MyRestServiceClient;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyRestServiceController {

	@Inject
	private MyRestServiceClient myRestServiceClient;

	@RequestMapping(value = "/abc/def/{name}/{rollNo}", headers = "Accept=application/json")
	public MyMainResponse callRestClientService(@PathVariable String name,@PathVariable String rollNo) {
		MyRestServiceRequest myRestServiceRequest = new MyRestServiceRequest();
		myRestServiceRequest.setName(name);
		myRestServiceRequest.setRollNo(rollNo);
		
		MyMainResponse myMainResponse = myRestServiceClient
				.callTheRestService(myRestServiceRequest);
		return myMainResponse;

	}
}
