package myRestService.service;

import myRestService.domain.MyMainResponse;
import myRestService.domain.MyRestServiceResponse;

public class MyRestServiceResponseToMyMainResponseConverter {

	
	public MyMainResponse convert(MyRestServiceResponse myRestServiceResponse){
		MyMainResponse myMainResponse =new MyMainResponse();
		
		myMainResponse.setDob(myRestServiceResponse.getDob());
		myMainResponse.setStandard(myRestServiceResponse.getStandard());
		
		return myMainResponse;
		
	}
}
