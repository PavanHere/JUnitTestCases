package myRestService.service;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import myRestService.domain.MyMainResponse;
import myRestService.domain.MyRestServiceRequest;
import myRestService.domain.MyRestServiceResponse;

@Service
public class MyRestServiceClient {

	@Inject
	private RestTemplate restTemplate;

	@Inject
	private HttpHeaderBuilder httpHeaderBuilder;
	@Inject
	private Logger logger;
	@Inject
	private MyRestServiceResponseToMyMainResponseConverter myRestServiceResponseToMyMainResponseConverter;

	public MyMainResponse callTheRestService(
			MyRestServiceRequest myRestServiceRequest) {
		MyMainResponse myMainResponse = null;
		ResponseEntity<MyRestServiceResponse> response = null;
		// create url
		String url = "http://www.abchyderabad.com";

		// build headers
		HttpHeaders buildHeaders = httpHeaderBuilder.buildHeaders();

		// create request entity
		HttpEntity<MyRestServiceRequest> requestEntity = new HttpEntity<MyRestServiceRequest>(
				myRestServiceRequest, buildHeaders);

		// call rest service
		try {
			response = restTemplate.exchange(url, HttpMethod.POST,
					requestEntity, MyRestServiceResponse.class);
		} catch (Exception e) {
			logger.debug("it throws an exception", e);
		}
		return myRestServiceResponseToMyMainResponseConverter.convert(response.getBody());

	}

}
