package myRestService.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

@Service
public class HttpHeaderBuilder {
	
	public HttpHeaders buildHeaders(){
		HttpHeaders httpHeaders=new HttpHeaders();
		
		httpHeaders.set("myFirst", "pawan");
		httpHeaders.set("mySecond", "Kumar");
		
		
		return httpHeaders;
		
	}

}
