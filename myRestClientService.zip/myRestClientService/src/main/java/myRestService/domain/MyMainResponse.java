package myRestService.domain;

public class MyMainResponse {
	private String standard;
	private String dob;

	public String getStandard()  {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
