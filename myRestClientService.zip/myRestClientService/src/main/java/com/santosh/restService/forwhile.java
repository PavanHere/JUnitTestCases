package com.santosh.restService;

public class forwhile {
public static void main(String[] args) {
	
	
	long i=System.currentTimeMillis();
	for (int j = 0; j <10; j++) {
		
	}
	long j1=System.currentTimeMillis();
	System.out.println(j1-i);
}
}
