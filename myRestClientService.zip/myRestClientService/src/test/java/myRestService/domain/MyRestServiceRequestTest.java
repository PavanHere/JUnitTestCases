package myRestService.domain;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyRestServiceRequestTest {

	@InjectMocks
	private MyRestServiceRequest myRestServiceRequest;

	@Test
	public void testName() throws Exception {

		myRestServiceRequest.setName("pawan");

		assertEquals(myRestServiceRequest.getName(), "pawan");
	}

	@Test
	public void testRollNo() throws Exception {
		myRestServiceRequest.setRollNo("20");
		assertEquals(myRestServiceRequest.getRollNo(),"20");
	}
}
