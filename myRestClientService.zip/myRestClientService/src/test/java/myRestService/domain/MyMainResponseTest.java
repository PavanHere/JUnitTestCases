package myRestService.domain;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyMainResponseTest {
	
	@InjectMocks
	private MyMainResponse myMainResponse;
	
	@Test
	public void testStandard() throws Exception {
		myMainResponse.setStandard("second class");
		
		assertEquals("second class", myMainResponse.getStandard());
	}
	
	@Test
	public void testDob() throws Exception {
		myMainResponse.setDob("26");
		assertEquals("26", myMainResponse.getDob());
	}
}
