package myRestService.domain;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyRestServiceResponseTest {

	@InjectMocks
	private MyRestServiceResponse myRestServiceResponse;
	
	@Test
	public void testStandard() throws Exception {
		myRestServiceResponse.setStandard("second class");
		
		assertEquals("second class", myRestServiceResponse.getStandard());
	}
	@Test
	public void testAddress() throws Exception {
		myRestServiceResponse.setAddress("atoz");;
		
		assertEquals("atoz", myRestServiceResponse.getAddress());
	}
	
	@Test
	public void testDob() throws Exception {
		myRestServiceResponse.setDob("26");
		assertEquals("26", myRestServiceResponse.getDob());
	}
}
