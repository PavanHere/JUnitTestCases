package myRestService.service;

import static org.junit.Assert.*;
import myRestService.domain.MyMainResponse;
import myRestService.domain.MyRestServiceResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyRestServiceResponseToMyMainResponseConverterTest {
	@InjectMocks
	private MyRestServiceResponseToMyMainResponseConverter myRestServiceResponseToMyMainResponseConverter;

	@Test
	public void testName() throws Exception {
		MyRestServiceResponse myRestServiceResponse=new MyRestServiceResponse();
		
		myRestServiceResponse.setAddress("address");
		myRestServiceResponse.setDob("dob");
		myRestServiceResponse.setStandard("standard");
		MyMainResponse response = myRestServiceResponseToMyMainResponseConverter.convert(myRestServiceResponse);
		
		assertEquals("dob", response.getDob());
		assertEquals("standard", response.getStandard());
	}
}
