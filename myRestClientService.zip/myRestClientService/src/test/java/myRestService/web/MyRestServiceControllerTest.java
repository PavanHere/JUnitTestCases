package myRestService.web;

import static org.junit.Assert.*;
import myRestService.domain.MyMainResponse;
import myRestService.domain.MyRestServiceRequest;
import myRestService.service.MyRestServiceClient;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MyRestServiceControllerTest {

	@InjectMocks
	private MyRestServiceController myRestServiceController;
	@Mock
	private MyRestServiceClient myRestServiceClient;
	@Mock
	private MyRestServiceRequest myRestServiceRequest;
	
	@Test
	public void testName() throws Exception {

		Mockito.when(
				myRestServiceClient
						.callTheRestService((MyRestServiceRequest) Mockito.anyObject())).thenReturn(createMyResponse());

		MyMainResponse callRestClientService = myRestServiceController
				.callRestClientService("pawan","20");

		assertEquals(createMyResponse().getDob(),
				callRestClientService.getDob());

	}


	

	private MyMainResponse createMyResponse() {
		MyMainResponse myMainResponse = new MyMainResponse();
		myMainResponse.setDob("dob");
		myMainResponse.setStandard("standard");
		return myMainResponse;

	}
}
